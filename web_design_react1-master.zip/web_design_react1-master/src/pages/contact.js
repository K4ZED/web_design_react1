import React from "react";

export default class Contact extends React.Component{
    render(){
        return(
            <div className="container">
                <div className="alert alert-info">
                    <h1>Ini adalah halaman Contact</h1>
                </div>
            </div>
        )
    }
}