import React from "react";

export default class About extends React.Component{
    render(){
        return(
            <div className="container">
                <div className="alert alert-danger">
                    <h1>Ini adalah halaman About</h1>
                </div>
            </div>
        )
    }
}